from pathlib import Path
import json,hashlib,os,collections,zipfile
R=Path('/mnt/data/w5_v33');S=Path('/mnt/data/w5_v30');PREV=Path('/mnt/data/w5_v31'); sha=lambda b:hashlib.sha256(b).hexdigest()
p32=PREV/'V32_FROZEN_PARITY_DIAGNOSTIC_PLAN.json';assert sha(p32.read_bytes())=='60775cadd4f4c1d7b26ea34a8667db862ff61b12ff73fd1ae108bd3c4aff82ab'
old=json.loads(p32.read_bytes());visited={(x['ch'],x['route']):set(x['ordinals']) for x in old['tasks'] if x['ch'] in (0,4)};assert len(visited)==62
work=[];counts=collections.Counter();routes=collections.Counter();original_total=0
for ch in (0,4):
 manifest=S/f'CH{ch}/V27_FULL10_PRE_ECON_CH{ch}/ALL_ROUTES_MANIFEST.json';m=json.loads(manifest.read_bytes());assert len(m['routes'])==31
 for route in m['routes']:
  name=route['route'];n=route['physical_masks'];prior=visited[(ch,name)];assert len(prior)==5 and prior==set((0,n//4,n//2,(3*n)//4,n-1))
  remain=[i for i in range(n) if i not in prior];assert len(remain)==n-5
  original_total+=n;counts[ch]+=len(remain);routes[ch]+=1
  for lo in range(0,len(remain),20):
   ordinals=remain[lo:lo+20]
   work.append({'ch':ch,'route':name,'ordinals':ordinals,'pre_existing_v32_ordinals':sorted(prior),'original_physical_mask_rows':n,'source_candidate_root_sha256':route['candidate_root'],'sampling':'ALL_PREVIOUSLY_UNTESTED_ORIGINAL_PHYSICAL_MASK_ORDINALS_EXCLUDING_ONLY_V32_5_FIXED_EX_ANTE','source_channel_manifest_sha256':sha(manifest.read_bytes())})
assert original_total==13962 and counts=={0:6813,4:6839} and len(work)>600
assert {x['ch'] for x in work}=={0,4}
plan={'schema':'QROS_W5_V33_PNL_BLIND_REMAINING_LARGE_CHANNEL_ALL_MASK_PARITY_PLAN_V1','state':'FROZEN_BEFORE_ANY_V33_EXECUTION','parent_v32_live_pointer_git_blob_sha1':'aa9ea12ffef8fa1d4e30322d75aeaf0b7640ac06','parent_v32_archive_sha256':'3be95e1c69078fcba52f9a5a319a905d987044d23af09ac872e17eb745811b8d','prior_V32_pnl_blind_plan_sha256':'60775cadd4f4c1d7b26ea34a8667db862ff61b12ff73fd1ae108bd3c4aff82ab','prior_V32_closed_mask_occurrences_CH0_CH4':310,'original_V28_raw_tick_sha256':'3ddb3c95acb9284196c5b6db84385271702800209ee33b1b1a2e1bd59cc9ff53','original_V28_semantic_configs_unchanged':22352,'original_V28_economic_shards_untouched':104,'sampling':'At each original untouched mask, independently replay up to 128 evenly spaced original accepted frozen candidate indices without using economic results, cost scores or prior replay outcomes. Same frozen original masks and candidate tapes.','channels':[0,4],'mask_chunk_size':20,'remaining_mask_ordinals_per_channel':dict(counts),'original_physical_masks_CH0_plus_CH4':original_total,'previous_v32_masks_CH0_plus_CH4_excluded':310,'total_remaining_masks':sum(counts.values()),'frozen_tasks':work,'gates':{'holdout_open':False,'GA2_open':False,'Gate_A_approved':False,'new_economic_PnL':False,'old_W3_touched':False}}
p=R/'V33_FROZEN_REMAINING_ALL_MASK_PLAN.json';tmp=p.with_suffix('.partial');tmp.write_text(json.dumps(plan,sort_keys=True,indent=2)+'\n');os.replace(tmp,p)
receipt={'schema':'QROS_W5_V33_PLAN_FROZEN_PRE_REPLAY_RECEIPT','plan_SHA256':sha(p.read_bytes()),'tasks':len(work),'original_physical_masks_CH0_CH4':original_total,'already_v32_verified_mask_occurrences':310,'remaining_mask_occurrences':sum(counts.values()),'by_channel':dict(counts),'zero_expost_selection':True,'no_new_PnL':True,'scientific_gates_locked':True}
r=R/'V33_PLAN_FROZEN_RECEIPT.json';r.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
zipf=R/'QROS_W5_V33_EXANTE_FROZEN_REMAINING_CH0_CH4_PLAN_20260925.zip';part=zipf.with_suffix('.partial')
with zipfile.ZipFile(part,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in (p,r,R/'freeze_v33_remaining_all_mask_plan.py'):z.write(f,f.name)
os.replace(part,zipf)
with zipfile.ZipFile(zipf) as z:assert z.testzip() is None
print('V33_EXANTE_PLAN_FROZEN','TASKS',len(work),'MASKS',sum(counts.values()),'BY_CHANNEL',dict(counts),'ORIGINAL_CH0_CH4_MASKS',original_total,'V32_ALREADY_TESTED',310)
for x in (p,r,zipf):print('ASSET',x.name,'bytes',x.stat().st_size,'sha256',sha(x.read_bytes()))
