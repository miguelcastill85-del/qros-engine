#!/usr/bin/env python3
"""Independent, PnL-blind predeclared V33 direct real-tick per-mask parity.
Never rerun previously closed V30 CH1/CH5, V28 economic result or holdout.
"""
from pathlib import Path
import json,os,hashlib,sys,argparse,time
import numpy as np
R=Path('/mnt/data/w5_v33');PREV=Path('/mnt/data/w5_v31');SRC=Path('/mnt/data/w5_v30');sys.path.insert(0,str(SRC))
from independent_fullmask_stratified_parity_v30 import original,sha
from REFERENCE_ONLY_seed0076_direct_dev_backtest_v2 import simulate,DTYPE
from qros_w5_v28_frozen_exploratory_economic_kernel import schedule_pure
PIN='2be3c09dbcf80576125187f45ae9e7c8ce265a67bab6170a3809adb6a464dc0c';RAW='3ddb3c95acb9284196c5b6db84385271702800209ee33b1b1a2e1bd59cc9ff53'
ARCH={0:'196de55420e5c29f3ef776d32179842309826585e2fd7d6580fe73f95561ffa2',4:'79d30dd8c734c845025583261fd50bd88392c0ce03d21764f8d82eb4d351ea76'}

def atom(p,o):
 tmp=p.with_suffix('.partial');tmp.write_text(json.dumps(o,sort_keys=True,indent=2,allow_nan=False)+'\n');os.replace(tmp,p)

def run(ch,max_seconds=100,max_new_shards=6):
 assert ch in ARCH and sha(R/'V33_FROZEN_REMAINING_ALL_MASK_PLAN.json')==PIN
 plan=json.loads((R/'V33_FROZEN_REMAINING_ALL_MASK_PLAN.json').read_text())
 assert plan['state']=='FROZEN_BEFORE_ANY_V33_EXECUTION' and len(plan['frozen_tasks'])==710
 assert json.loads((SRC/'CARRIER_RECOVERY_FINAL.json').read_text())['exact_full_sha256']==RAW
 pin=json.loads((PREV/f'RECOVERY_CH{ch}.json').read_text());assert pin['archive_sha256']==ARCH[ch] and pin['status']=='PASS'
 assert sha(PREV/f'QROS_SEED0076_W5_V28_CHANNEL_{ch}_FULL_CAUSAL_AND_ECONOMIC_EVIDENCE.zip')==ARCH[ch]
 side=1 if ch<4 else -1;basedir=SRC/f'CH{ch}/V27_FULL10_PRE_ECON_CH{ch}';M=json.loads((basedir/'ALL_ROUTES_MANIFEST.json').read_text());meta={x['route']:x for x in M['routes']};arts={x['name']:x['sha256'] for x in M['artifacts']}
 tasks=[x for x in plan['frozen_tasks'] if x['ch']==ch];assert tasks
 ticks=np.memmap(SRC/'XAUUSD_DEV_PACKED17_151382388.bin',dtype=DTYPE,mode='r')
 tapes={};out=R/'V33_SHARD_RECEIPTS';out.mkdir(exist_ok=True)
 start=time.monotonic();done=0;new_done=0
 for task in tasks:
  route=task['route'];ordinals=task['ordinals'];name=f'CH{ch}_{route}_I{ordinals[0]:03d}_{ordinals[-1]:03d}.json';p=out/name
  if p.exists():
   q=json.loads(p.read_text());assert q['status']=='PASS' and q['plan_SHA256']==PIN and q['ordinals']==ordinals and q['original_channel_archive_sha256']==ARCH[ch]
   print('V33_REUSE_SHA',ch,route,ordinals[0],ordinals[-1],sha(p),flush=True);done+=1;continue
  if new_done>=max_new_shards or (new_done>0 and time.monotonic()-start>max_seconds):
   print('V33_BOUNDED_PAUSE_PASS',ch,'verified_this_run',done,'task_progress',len(list(out.glob(f'CH{ch}_*.json'))),'time',round(time.monotonic()-start,3),flush=True);return 75
  expected=meta[route];raw_route=route.split('_batch')[0];
  if raw_route not in tapes:tapes[raw_route]=original(ch,raw_route)
  tape_m,tr=tapes[raw_route];assert tape_m['source_candidate_root']==task['source_candidate_root_sha256']==expected['candidate_root']
  phys=basedir/f'{route}_PHYSICAL.jsonl';mask=basedir/f'{route}_PHYSICAL_MASKS.npz'
  assert sha(phys)==arts[phys.name] and sha(mask)==arts[mask.name]
  rows=[json.loads(x) for x in phys.read_text().splitlines()];assert len(rows)==task['original_physical_mask_rows']==expected['physical_masks']
  tested=[];sig_total=trade_total=field_total=0
  with np.load(mask,allow_pickle=False) as z:
   assert str(z['candidate_root_sha256'])==tape_m['source_candidate_root']
   for i in ordinals:
    row=rows[i];mid=str(z['mask_ids'][i]);assert mid==row['physical_mask_id']
    selected=np.flatnonzero(np.unpackbits(z['masks'][i],bitorder='little')[:len(tr['source_idx'])]);assert len(selected)==row['accepted_signal_count']
    # Empty accepted masks are valid original V28 physical-mask rows: fixed PnL-blind ordinal plan must NOT be changed.
    keep=selected[np.unique(np.linspace(0,len(selected)-1,min(len(selected),128),dtype=np.int64))] if len(selected) else selected
    direct,rejections,missing=simulate(ticks,tr['source_idx'][keep],np.full(len(keep),side,np.int8),tr['stop'][keep],keep,3)
    cached=schedule_pure(ticks['ts'],tr['source_idx'],keep,tr['entry_idx'],tr['exit_idx'],tr['entry_price'],tr['exit_price'],tr['risk'],tr['reason'],tr['stop'],side,3,True)
    if len(missing) or len(direct)!=cached[0] or cached[5][5] or not np.array_equal(rejections[:6],cached[5][:6]):
     raise AssertionError(('V33_REJECTIONS_DRIFT',ch,route,i,len(missing),len(direct),cached[0],rejections[:6].tolist(),cached[5][:6].tolist()))
    if not np.array_equal(direct[:,[0,1,2,3,4,5,6,7,9,10]],cached[6][:,[0,1,2,3,4,5,6,7,9,10]]) or not np.allclose(direct[:,8],cached[6][:,8],atol=1e-14,rtol=0):
     raise AssertionError(('V33_11_FIELD_DRIFT',ch,route,i))
    sig_total+=len(keep);trade_total+=len(direct);field_total+=11*len(direct)
    tested.append({'ordinal':i,'physical_mask_id':mid,'original_accepted_source_signals':len(selected),'PNL_blind_sampled_source_signals':len(keep),'independent_exact_trades':len(direct),'11_fields_compared':11*len(direct),'all_rejections_equal':True,'zero_signal_mask':len(selected)==0})
  result={'schema':'QROS_W5_V33_INDEPENDENT_FROZEN_REMAINING_LARGE_CHANNEL_MASK_PARITY_SHARD_V1','status':'PASS','channel':ch,'route':route,'raw_route':raw_route,'side':'BUY' if side==1 else 'SELL','plan_SHA256':PIN,'original_raw_sha256':RAW,'original_channel_archive_sha256':ARCH[ch],'original_tape_manifest_SHA256':sha(SRC/f'CH{ch}/V28_ECON_TAPE_CH{ch}_{raw_route}/FULL_TRAJECTORY_MANIFEST.json'),'original_mask_SHA256':sha(mask),'original_physical_map_SHA256':sha(phys),'independent_simulator_sha256':sha(SRC/'REFERENCE_ONLY_seed0076_direct_dev_backtest_v2.py'),'preexisting_V28_cached_kernel_sha256':sha(SRC/'qros_w5_v28_frozen_exploratory_economic_kernel.py'),'ordinals':ordinals,'full_original_physical_rows':len(rows),'tested_mask_occurrences':len(ordinals),'sampled_signals':sig_total,'independent_exact_trades':trade_total,'exact_fields':field_total,'tests':tested,'new_economic_PNL':False,'Gate_A_approved':False,'holdout_open':False,'ga2_open':False,'historical_broker_account_commission_certified':False}
  atom(p,result);done+=1;new_done+=1;print('V33_SHARD_PASS',ch,route,len(ordinals),'signals',sig_total,'exact_trades',trade_total,'fields',field_total,'receipt_SHA256',sha(p),flush=True)
 print('V33_CHANNEL_PASS',ch,'all_task_count',len(tasks),'elapsed_seconds',round(time.monotonic()-start,3),flush=True);return 0
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--channel',type=int,choices=sorted(ARCH),required=True);ap.add_argument('--max-seconds',type=float,default=100);ap.add_argument('--max-new-shards',type=int,default=6);q=ap.parse_args();raise SystemExit(run(q.channel,q.max_seconds,q.max_new_shards))
