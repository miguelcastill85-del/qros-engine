#!/usr/bin/env python3
"""Pure read-only audit of immutable V33 PnL-blind shards + atomic durable partial archive."""
from pathlib import Path
import json,hashlib,collections,zipfile,os
R=Path('/mnt/data/w5_v33');H=lambda b:hashlib.sha256(b).hexdigest()
plan_path=R/'V33_FROZEN_REMAINING_ALL_MASK_PLAN.json';expected_sha='2be3c09dbcf80576125187f45ae9e7c8ce265a67bab6170a3809adb6a464dc0c'
assert H(plan_path.read_bytes())==expected_sha
plan=json.loads(plan_path.read_bytes());assert plan['state']=='FROZEN_BEFORE_ANY_V33_EXECUTION' and len(plan['frozen_tasks'])==710
runner=R/'v33_run_frozen_remaining_large_mask_parity.py';assert H(runner.read_bytes())=='d545f846a09dc2059193c5a9a6703235bf9f27554ac802eafdf4c032b5a501bf'
all_tasks={(t['ch'],t['route'],tuple(t['ordinals'])):t for t in plan['frozen_tasks']};assert len(all_tasks)==710
files=sorted((R/'V33_SHARD_RECEIPTS').glob('*.json'));actual={};metrics=collections.Counter();chs=collections.Counter();zero=[];rows=[]
for f in files:
 q=json.loads(f.read_bytes());key=(q['channel'],q['route'],tuple(q['ordinals']))
 assert key in all_tasks and key not in actual and q['status']=='PASS' and q['plan_SHA256']==expected_sha
 assert q['original_raw_sha256']==plan['original_V28_raw_tick_sha256'] and len(q['tests'])==len(q['ordinals'])==q['tested_mask_occurrences']
 assert q['original_physical_map_SHA256'] and q['original_mask_SHA256'] and q['original_tape_manifest_SHA256']
 assert not (q['new_economic_PNL'] or q['Gate_A_approved'] or q['holdout_open'] or q['ga2_open'])
 assert q['full_original_physical_rows']==all_tasks[key]['original_physical_mask_rows']
 assert [t['ordinal'] for t in q['tests']]==q['ordinals']
 assert set(q['ordinals']).isdisjoint(all_tasks[key]['pre_existing_v32_ordinals'])
 for t in q['tests']:
  assert t['11_fields_compared']==11*t['independent_exact_trades'] and t['all_rejections_equal'] and 0<=t['PNL_blind_sampled_source_signals']<=128
  assert t['PNL_blind_sampled_source_signals']==min(t['original_accepted_source_signals'],128)
  if t['original_accepted_source_signals']==0:
   assert t.get('zero_signal_mask',True) and t['independent_exact_trades']==0
   zero.append((q['channel'],q['route'],t['ordinal']))
 assert q['exact_fields']==11*q['independent_exact_trades']
 assert sum(t['independent_exact_trades'] for t in q['tests'])==q['independent_exact_trades']
 assert sum(t['PNL_blind_sampled_source_signals'] for t in q['tests'])==q['sampled_signals']
 actual[key]=H(f.read_bytes());chs[q['channel']]+=1
 for k,v in (('masks',q['tested_mask_occurrences']),('samples',q['sampled_signals']),('trades',q['independent_exact_trades']),('fields',q['exact_fields'])):metrics[k]+=v
 rows.append({'filename':f.name,'sha256':actual[key],'ch':q['channel'],'route':q['route'],'ordinals':q['ordinals'],'masks':q['tested_mask_occurrences'],'sampled_signals':q['sampled_signals'],'exact_trades':q['independent_exact_trades'],'matching_fields':q['exact_fields']})
assert len(actual)==len(files) and chs.keys()=={0,4}
# A genuinely frozen prefix of each channel's original task ordering: no retrospective sampling changes.
for ch in (0,4):
 expected_prefix=[t for t in plan['frozen_tasks'] if t['ch']==ch][:chs[ch]]
 assert set((t['ch'],t['route'],tuple(t['ordinals'])) for t in expected_prefix)==set(k for k in actual if k[0]==ch)
next_task={ch:(lambda tail:{'route':tail['route'],'next_ordinals':tail['ordinals'],'next_mask_ordinal_start':tail['ordinals'][0]} if tail else None)([t for t in plan['frozen_tasks'] if t['ch']==ch][chs[ch]:chs[ch]+1][0] if chs[ch]<sum(t['ch']==ch for t in plan['frozen_tasks']) else None) for ch in (0,4)}
master={'schema':'QROS_W5_V33_VERIFIED_PNL_BLIND_PARTIAL_SHARD_PROGRESS_RECEIPT_V1','status':'DEVELOPMENT_RUNNING_SHA_VERIFIED_RESTARTABLE','frozen_plan_sha256':expected_sha,'source_runner_sha256':H(runner.read_bytes()),'pre_execution_Git_plan_sha1':'3f88c26db37daa71d5234bfb61a7e9ba0763c91f','pre_execution_Git_runner_sha1':'afbd552496e580e47594ad5b059127b2ae0f12d2','original_raw_sha256':'3ddb3c95acb9284196c5b6db84385271702800209ee33b1b1a2e1bd59cc9ff53','planned_shards':710,'completed_shards':len(actual),'pending_shards':710-len(actual),'by_channel_complete':dict(chs),'by_channel_planned':{str(ch):sum(t['ch']==ch for t in plan['frozen_tasks'])for ch in (0,4)},'mask_occurrences_covered_new':metrics['masks'],'sampled_source_signals_new':metrics['samples'],'identical_independent_trades_new':metrics['trades'],'matching_independent_fields_new':metrics['fields'],'zero_signal_original_masks_new':zero,'next_frozen_task_per_channel':next_task,'prior_v30_v32_independent_verified_mask_occurrences':1189,'prior_v30_v32_exact_trades':107270,'prior_v30_v32_exact_fields':1179970,'original_v28_semantic_configs_economically_closed_exposed_DEV':22352,'original_v28_economic_shards_untouched':104,'holdout_open':False,'ga2_open':False,'Gate_A_approved':False,'no_new_PnL':True,'historical_account_commission_certified':False,'historical_symbol_special_hours_certified':False,'receipt_byte_manifest':rows,'next_automatic_action':'Resume exclusively next exact unverified original V33 predeclared CH0/CH4 shard from frozen plan SHA; bounded by per-worker max 40 seconds/6 new shards and external timeout; immutable original V28 and V30-V32 receipts remain untouched.'}
masterp=R/'V33_PARTIAL_MASTER_RECEIPT.json';masterp.write_text(json.dumps(master,sort_keys=True,indent=2)+'\n')
assets=[('FROZEN_PLAN/'+plan_path.name,plan_path),('MASTER/'+masterp.name,masterp),('SOURCE/'+runner.name,runner),('SOURCE/freeze_v33_remaining_all_mask_plan.py',R/'freeze_v33_remaining_all_mask_plan.py'),('SOURCE/build_v33_incremental_verified_checkpoint.py',R/'build_v33_incremental_verified_checkpoint.py'),('FROZEN_PLAN/V33_PLAN_FROZEN_RECEIPT.json',R/'V33_PLAN_FROZEN_RECEIPT.json')]+[('RECEIPTS/'+f.name,f)for f in files]
manifest={'schema':'QROS_W5_V33_PROGRESS_ALL_RECEIPT_MEMBER_SHA256_MANIFEST_V1','files':[{'name':name,'bytes':f.stat().st_size,'sha256':H(f.read_bytes())} for name,f in assets]}
manp=R/'V33_PARTIAL_INTERNAL_MANIFEST.json';manp.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
archive=R/f'QROS_W5_V33_VERIFIED_{len(files)}_OF_710_MASK_PARITY_SHARDS_20260925.zip';tmp=archive.with_suffix('.zip.partial')
with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,f in assets:z.write(f,name)
 z.write(manp,'MANIFEST/V33_PARTIAL_INTERNAL_MANIFEST.json')
os.replace(tmp,archive)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(assets)+1
 for e in manifest['files']:
  raw=z.read(e['name']);assert len(raw)==e['bytes'] and H(raw)==e['sha256']
print('V33_PARTIAL_RECEIPT_AUDIT_PASS planned',710,'verified',len(actual),'remaining',710-len(actual),'channels',dict(chs))
print('V33_INDEPENDENT_PARITY_MASKS',metrics['masks'],'SAMPLED_EVENTS',metrics['samples'],'EXACT_TRADES',metrics['trades'],'EXACT_FIELDS',metrics['fields'],'ZERO_MASKS',len(zero))
print('V33_BOUNDED_NEXT',next_task)
for x in (archive,masterp,manp):print('V33_ARTIFACT',x.name,'BYTES',x.stat().st_size,'SHA256',H(x.read_bytes()))
